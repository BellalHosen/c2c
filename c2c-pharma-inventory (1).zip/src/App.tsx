import React, { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';
import { Database } from './types/database.types';

type InventoryItem = Database['public']['Tables']['inventory']['Row'];
type Transaction = Database['public']['Tables']['transactions']['Row'];
type AuditLog = Database['public']['Tables']['audit_log']['Row'];
type UserProfile = Database['public']['Tables']['profiles']['Row'];

import { 
  LayoutDashboard, 
  Package, 
  ArrowDownCircle, 
  ArrowUpCircle, 
  History, 
  ListChecks, 
  FileText, 
  Users, 
  UserPlus, 
  Database as DatabaseIcon, 
  LogOut,
  AlertCircle,
  TrendingUp,
  Search,
  Printer,
  Download,
  Trash2,
  Upload,
  Plus,
  Edit,
  Filter,
  ChevronRight,
  CheckCircle,
  Ban,
  LogIn,
  Menu,
  X
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { motion } from 'motion/react';
import { cn } from './lib/utils';

// Mock Data (Fallback if database is empty)
const INITIAL_STOCK_MOVEMENT_DATA = [
  { name: 'Apr 05', count: 0 },
  { name: 'Apr 09', count: 0 },
  { name: 'Apr 13', count: 0 },
  { name: 'Apr 17', count: 0 },
  { name: 'Apr 21', count: 100 },
  { name: 'Apr 22', count: 90000 },
  { name: 'Apr 23', count: 100 },
  { name: 'Apr 27', count: 0 },
  { name: 'May 01', count: 0 },
  { name: 'May 03', count: 0 },
];

const RECENT_ACTIVITY = [
  { id: 1, type: 'ISSUE', text: 'Issued 2 Nos of CE-02-08-0118 (2 -> 0)', user: 'H. M. Nahid Parves', time: 'May 2, 3:49 PM' },
  { id: 2, type: 'ISSUE', text: 'Issued 1 Pcs of CE-02-08-0928 (6 -> 5)', user: 'H. M. Nahid Parves', time: 'May 2, 3:46 PM' },
  { id: 3, type: 'ISSUE', text: 'Issued 1 Pcs of CE-02-08-0232 (5 -> 4)', user: 'H. M. Nahid Parves', time: 'May 2, 3:45 PM' },
  { id: 4, type: 'UPDATE', text: 'Updated item CE-02-08-0955', user: 'Md. Bellal Hosen', time: 'Apr 30, 4:19 PM' },
];

const TOP_MOVING_ITEMS = [
  { sku: 'CE-02-08-1037', name: 'Busbar Tube set, 130mm, Yellow', movement: 13584 },
];

const INVENTORY_DATA = [
  { code: 'CE-02-08-0894', name: '05MM P P Sheet (4 × 8 Feet)', location: '13D', unit: 'Pcs', uses: '-', opening: 0, current: 0, price: '0.00', status: 'out' },
  { code: 'CE-02-08-0116', name: '1 gang switch', location: '2D', unit: 'Nos', uses: '-', opening: 3, current: 3, price: '0.00', status: 'in' },
  { code: 'CE-02-08-0605', name: '1 × 2Rm cable', location: '9D', unit: 'Coil', uses: '-', opening: 0, current: 0, price: '0.00', status: 'out' },
  { code: 'CE-02-08-0606', name: '1 × 500Rm cable', location: '9D', unit: 'Feet', uses: '-', opening: 36, current: 36, price: '0.00', status: 'in' },
  { code: 'CE-02-08-0150', name: '2 Pin Plug', location: '2D', unit: 'Nos', uses: '-', opening: 1, current: 1, price: '0.00', status: 'in' },
  { code: 'CE-02-08-0117', name: '2 gang switch', location: '2D', unit: 'Nos', uses: '-', opening: 1, current: 1, price: '0.00', status: 'in' },
  { code: 'CE-02-08-0603', name: '2 × 0.75Rm cable', location: '9D', unit: 'Coil', uses: '-', opening: 0, current: 0, price: '0.00', status: 'out' },
  { code: 'CE-02-08-0608', name: '25 × 0.5Rm cable', location: '9D', unit: 'Feet', uses: '-', opening: 0, current: 0, price: '0.00', status: 'out' },
  { code: 'CE-02-08-0612', name: '2×2.5 Rm cable', location: '7E', unit: 'Feet', uses: '-', opening: 592, current: 592, price: '0.00', status: 'in' },
];

const TRANSACTION_DATA = [
  { date: 'May 3 26, 15:59', type: 'ISSUE', code: 'CE-02-08-1091', item: 'Birch Gray paint', qty: -1, balance: 2, reference: 'IS:189', party: 'Rakib', user: 'H. M. Nahid Parves' },
  { date: 'May 3 26, 15:58', type: 'ISSUE', code: 'CE-02-08-0884', item: 'Painting Brush 2"', qty: -2, balance: 4, reference: 'IS:189', party: 'Rakib', user: 'H. M. Nahid Parves' },
  { date: 'May 3 26, 15:58', type: 'ISSUE', code: 'CE-02-08-0117', item: '2 gang switch', qty: -1, balance: 0, reference: 'IS:189', party: 'Rakib', user: 'H. M. Nahid Parves' },
  { date: 'May 2 26, 15:49', type: 'ISSUE', code: 'CE-02-08-0118', item: '4 gang switch', qty: -2, balance: 0, reference: 'IS:188', party: 'Monir', user: 'H. M. Nahid Parves' },
  { date: 'May 2 26, 15:46', type: 'ISSUE', code: 'CE-02-08-0928', item: "SS Ball Valve 1/2''", qty: -1, balance: 5, reference: 'IS:188', party: 'khokon', user: 'H. M. Nahid Parves' },
  { date: 'May 2 26, 15:45', type: 'ISSUE', code: 'CE-02-08-0232', item: 'Hammer Drill Bit Size: 6.5mm', qty: -1, balance: 4, reference: 'IS:188', party: 'Shakirul', user: 'H. M. Nahid Parves' },
  { date: 'Apr 30 26, 16:16', type: 'ISSUE', code: 'CE-02-08-0053', item: 'Cable tie 250 mm', qty: -1, balance: 17, reference: 'IS:187', party: 'Shakhawat', user: 'H. M. Nahid Parves' },
];

const AUDIT_LOG_DATA = [
  { when: 'May 3, 15:59:14', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#928', summary: 'Issued 1 Gallon of CE-02-08-1091 (3 -> 2)' },
  { when: 'May 3, 15:58:52', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#927', summary: 'Issued 2 Pcs of CE-02-08-0884 (6 -> 4)' },
  { when: 'May 3, 15:58:15', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#926', summary: 'Issued 1 Nos of CE-02-08-0117 (1 -> 0)' },
  { when: 'May 2, 15:49:09', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#925', summary: 'Issued 2 Nos of CE-02-08-0118 (2 -> 0)' },
  { when: 'May 2, 15:46:19', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#924', summary: 'Issued 1 Pcs of CE-02-08-0928 (6 -> 5)' },
  { when: 'May 2, 15:45:40', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#923', summary: 'Issued 1 Pcs. of CE-02-08-0232 (5 -> 4)' },
  { when: 'Apr 30, 16:19:36', user: 'Md. Bellal Hosen', action: 'UPDATE', entity: 'item#2440', summary: 'Updated item CE-02-08-0955' },
  { when: 'Apr 30, 16:16:40', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#922', summary: 'Issued 1 Pkt of CE-02-08-0053 (18 -> 17)' },
  { when: 'Apr 30, 16:16:18', user: 'H. M. Nahid Parves', action: 'ISSUE', entity: 'transaction#921', summary: 'Issued 2 Nos of CE-02-08-0137 (20 -> 18)' },
];

const USER_DATA = [
  { username: '-', fullname: 'System', email: '-', role: 'ADMIN', status: 'Disabled' },
  { username: '-', fullname: 'Nahid Parves', email: '-', role: 'USER', status: 'Disabled' },
  { username: '-', fullname: 'Diane Lee', email: '-', role: 'USER', status: 'Disabled' },
  { username: 'Admin', fullname: 'Administrator', email: '-', role: 'ADMIN', status: 'Active' },
  { username: 'Nahid', fullname: 'H. M. Nahid Parves', email: '-', role: 'USER', status: 'Active' },
  { username: 'Bellal', fullname: 'Md. Bellal Hosen', email: 'bellal.hosen@c2cpharma.com.bd', role: 'ADMIN', status: 'Active' },
];


export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [isSystemAdmin, setIsSystemAdmin] = useState(false);
  const isSystemAdminRef = React.useRef(false);

  useEffect(() => {
    isSystemAdminRef.current = isSystemAdmin;
  }, [isSystemAdmin]);

  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [receiveForm, setReceiveForm] = useState({ code: '', qty: 0, price: 0, party: '', reference: '', notes: '' });
  const [issueForm, setIssueForm] = useState({ code: '', qty: 0, party: '', reference: '', notes: '' });
  const [addMaterialForm, setAddMaterialForm] = useState({ code: '', name: '', location: '', unit: '', uses: '', opening: 0, price: 0 });
  const [showAddMaterial, setShowAddMaterial] = useState(false);
  const [signUpForm, setSignUpForm] = useState({ fullname: '', username: '', password: '', email: '', role: 'USER' });
  const [physCheckForm, setPhysCheckForm] = useState({ code: '', actual: 0 });

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQueries, setSearchQueries] = useState({
    inventory: '',
    transactions: '',
    audit: ''
  });
  const [lowStockOnly, setLowStockOnly] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (isSystemAdminRef.current) return;
      setIsAuthenticated(!!session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
        fetchAllData();
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (isSystemAdminRef.current) return;
      setIsAuthenticated(!!session);
      setUser(session?.user ?? null);
      if (session?.user) {
        fetchProfile(session.user.id);
        fetchAllData();
      } else {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const fetchProfile = async (userId: string) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (data) setProfile(data);
  };

  const fetchAllData = async () => {
    const [inv, tx, logs, usr] = await Promise.all([
      supabase.from('inventory').select('*').order('name'),
      supabase.from('transactions').select('*').order('date', { ascending: false }),
      supabase.from('audit_log').select('*').order('when', { ascending: false }),
      supabase.from('profiles').select('*')
    ]);

    if (inv.data) setInventory(inv.data);
    if (tx.data) setTransactions(tx.data);
    if (logs.data) setAuditLogs(logs.data);
    if (usr.data) setUsers(usr.data);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Default System Admin Fallback
    if (loginForm.email === 'System' && loginForm.password === 'Password') {
      setIsSystemAdmin(true);
      setIsAuthenticated(true);
      const mockUser = {
        id: 'system-admin',
        email: 'system@default.com',
      };
      setUser(mockUser);
      setProfile({
        id: 'system-admin',
        username: 'System',
        fullname: 'System Administrator',
        email: 'system@default.com',
        role: 'ADMIN',
        status: 'Active',
        updated_at: new Date().toISOString()
      });
      fetchAllData();
      setLoading(false);
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: loginForm.email,
      password: loginForm.password,
    });
    if (error) setError(error.message);
    setLoading(false);
  };

  const handleReceiveStock = async () => {
    if (!receiveForm.code || receiveForm.qty <= 0) return;
    setLoading(true);
    
    // 1. Get current stock
    const item = inventory.find(i => i.code === receiveForm.code);
    if (!item) return;

    const newCurrent = item.current + receiveForm.qty;

    // 2. Insert transaction
    const { error: txError } = await supabase.from('transactions').insert({
      type: 'RECEIVE',
      code: receiveForm.code,
      item: item.name,
      qty: receiveForm.qty,
      balance: newCurrent,
      reference: receiveForm.reference,
      party: receiveForm.party,
      user: profile?.fullname || user?.email || 'Unknown',
      date: new Date().toISOString()
    });

    if (txError) {
      alert('Error recording transaction: ' + txError.message);
      setLoading(false);
      return;
    }

    // 3. Update inventory
    await supabase.from('inventory').update({
      current: newCurrent,
      price: receiveForm.price || item.price,
      status: 'in'
    }).eq('code', receiveForm.code);

    // 4. Audit log
    await supabase.from('audit_log').insert({
      user: profile?.fullname || user?.email || 'Unknown',
      action: 'RECEIVE',
      entity: `item#${receiveForm.code}`,
      summary: `Received ${receiveForm.qty} ${item.unit} of ${receiveForm.code} (${item.current} -> ${newCurrent})`,
      when: new Date().toISOString()
    });

    setReceiveForm({ code: '', qty: 0, price: 0, party: '', reference: '', notes: '' });
    fetchAllData();
    setLoading(false);
    setActiveTab('Inventory Stock');
  };

  const handleIssueStock = async () => {
    if (!issueForm.code || issueForm.qty <= 0) return;
    setLoading(true);

    const item = inventory.find(i => i.code === issueForm.code);
    if (!item || item.current < issueForm.qty) {
      alert('Insufficient stock!');
      setLoading(false);
      return;
    }

    const newCurrent = item.current - issueForm.qty;

    const { error: txError } = await supabase.from('transactions').insert({
      type: 'ISSUE',
      code: issueForm.code,
      item: item.name,
      qty: -issueForm.qty,
      balance: newCurrent,
      reference: issueForm.reference,
      party: issueForm.party,
      user: profile?.fullname || user?.email || 'Unknown',
      date: new Date().toISOString()
    });

    if (txError) {
      alert('Error recording transaction: ' + txError.message);
      setLoading(false);
      return;
    }

    await supabase.from('inventory').update({
      current: newCurrent,
      status: newCurrent > 0 ? 'in' : 'out'
    }).eq('code', issueForm.code);

    await supabase.from('audit_log').insert({
      user: profile?.fullname || user?.email || 'Unknown',
      action: 'ISSUE',
      entity: `item#${issueForm.code}`,
      summary: `Issued ${issueForm.qty} ${item.unit} of ${issueForm.code} (${item.current} -> ${newCurrent})`,
      when: new Date().toISOString()
    });

    setIssueForm({ code: '', qty: 0, party: '', reference: '', notes: '' });
    fetchAllData();
    setLoading(false);
    setActiveTab('Inventory Stock');
  };

  const handleLogout = async () => {
    if (!isSystemAdmin) {
      await supabase.auth.signOut();
    }
    setIsSystemAdmin(false);
    setIsAuthenticated(false);
    setActiveTab('Dashboard');
  };

  const handleAddMaterial = async () => {
    if (!addMaterialForm.code || !addMaterialForm.name) return;
    setLoading(true);

    const { error } = await supabase.from('inventory').insert({
      ...addMaterialForm,
      current: addMaterialForm.opening,
      status: addMaterialForm.opening > 0 ? 'in' : 'out',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    });

    if (error) {
      alert('Error adding material: ' + error.message);
    } else {
      await supabase.from('audit_log').insert({
        user: profile?.fullname || user?.email || 'Unknown',
        action: 'CREATE',
        entity: `item#${addMaterialForm.code}`,
        summary: `Added new item ${addMaterialForm.name} (${addMaterialForm.code})`,
        when: new Date().toISOString()
      });
      setShowAddMaterial(false);
      setAddMaterialForm({ code: '', name: '', location: '', unit: '', uses: '', opening: 0, price: 0 });
      fetchAllData();
    }
    setLoading(false);
  };

  const handleSignUpUser = async () => {
    if (!signUpForm.email || !signUpForm.password) return;
    setLoading(true);

    // Supabase Auth signup
    let authId = '';
    if (!isSystemAdmin) {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: signUpForm.email,
        password: signUpForm.password,
      });

      if (authError) {
        alert('Error signing up user: ' + authError.message);
        setLoading(false);
        return;
      }
      authId = authData.user?.id || '';
    } else {
      // System Admin can just create profiles for testing if no real auth is possible
      authId = 'mock-' + Math.random().toString(36).substr(2, 9);
    }

    if (authId) {
      // Create profile
      const { error: profileError } = await supabase.from('profiles').insert({
        id: authId,
        username: signUpForm.username,
        fullname: signUpForm.fullname,
        email: signUpForm.email,
        role: signUpForm.role as any,
        status: 'Active',
        updated_at: new Date().toISOString()
      });

      if (profileError) {
        alert('Error creating user profile: ' + profileError.message);
      } else {
        alert('User created successfully!');
        setSignUpForm({ fullname: '', username: '', password: '', email: '', role: 'USER' });
        fetchAllData();
        setActiveTab('User Management');
      }
    }
    setLoading(false);
  };

  const handleDeleteItem = async (code: string) => {
    if (!confirm(`Are you sure you want to delete item ${code}? This action cannot be undone.`)) return;
    setLoading(true);
    const { error } = await supabase.from('inventory').delete().eq('code', code);
    if (error) {
      alert('Error deleting item: ' + error.message);
    } else {
      await supabase.from('audit_log').insert({
        user: profile?.fullname || 'System',
        action: 'DELETE',
        entity: 'INVENTORY',
        summary: `Deleted material ${code}`
      });
      fetchAllData();
    }
    setLoading(false);
  };

  const handleClearAllStock = async () => {
    if (!confirm('WARNING: THIS WILL DELETE ALL INVENTORY ITEMS PERMANENTLY. Proceed?')) return;
    setLoading(true);
    // Note: This matches all
    const { error } = await supabase.from('inventory').delete().neq('code', 'REALLY_UNLIKELY_CODE_123');
    if (error) {
      alert('Error clearing inventory: ' + error.message);
    } else {
      await supabase.from('audit_log').insert({
        user: profile?.fullname || 'System',
        action: 'DELETE_ALL',
        entity: 'INVENTORY',
        summary: 'Cleared all stock records'
      });
      fetchAllData();
    }
    setLoading(false);
  };

  const renderLogin = () => (
    <div className="min-h-screen flex flex-col bg-brand-bg">
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-[480px] bg-white rounded-2xl shadow-xl border border-slate-100 overflow-hidden transform transition-all">
          <div className="p-10 flex flex-col items-center">
            {/* Logo Section */}
            <div className="mb-8 text-center flex flex-col items-center">
              <div className="h-16 w-[180px] mb-4 flex items-center justify-center overflow-hidden">
                <img 
                  src="/src/assets/images/regenerated_image_1777800317392.png" 
                  alt="C2C Pharma Logo" 
                  className="h-full w-full object-contain"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    e.currentTarget.src = 'https://picsum.photos/seed/c2c/180/60';
                  }}
                />
              </div>
              <h1 className="text-2xl font-bold text-slate-800">C2C Pharma Ltd.</h1>
              <p className="text-slate-400 text-sm font-medium">Store Stock Manager</p>
            </div>

            <div className="w-full text-center mb-10">
              <h2 className="text-lg font-bold text-brand-navy">Sign in to continue</h2>
            </div>

            {/* Login Form */}
            <form onSubmit={handleLogin} className="w-full space-y-6">
              {error && (
                <div className="bg-red-50 text-red-600 p-3 rounded-lg text-xs font-bold border border-red-100 italic">
                  {error}
                </div>
              )}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Email / Username</label>
                <div className="relative">
                  <input 
                    type="text" 
                    required
                    value={loginForm.email}
                    onChange={(e) => setLoginForm(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium text-slate-700"
                    placeholder="Enter your email or username"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Password</label>
                <div className="relative">
                  <input 
                    type="password" 
                    required
                    value={loginForm.password}
                    onChange={(e) => setLoginForm(prev => ({ ...prev, password: e.target.value }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium text-slate-700"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-orange-600 text-white py-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-orange-700 transition-all shadow-lg active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <LogIn size={18} />
                    Login
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
      
      {/* Footer is now part of the layout */}
      <footer className="h-5 border-t border-slate-200 flex items-center justify-center bg-white">
        <p className="text-[9px] text-slate-400 font-medium tracking-wide">
          Designed by <span className="text-slate-500">Md. Bellal Hosen</span>. Engineering Department, C2C Pharma Ltd.
        </p>
      </footer>
    </div>
  );

  if (!isAuthenticated) return renderLogin();

  const sidebarItems = [
    { label: 'Dashboard', icon: LayoutDashboard },
    { label: 'Inventory Stock', icon: Package },
    { label: 'Receive Stock', icon: ArrowDownCircle },
    { label: 'Issue Stock', icon: ArrowUpCircle },
    { label: 'Transaction History', icon: History },
    { label: 'Stock Checks', icon: ListChecks },
    { label: 'Audit Trail', icon: FileText },
    { label: 'User Management', icon: Users },
    { label: 'Sign Up User', icon: UserPlus },
    { label: 'System Backup', icon: DatabaseIcon },
  ];

  const getChartData = () => {
    if (transactions.length === 0) return INITIAL_STOCK_MOVEMENT_DATA;

    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (29 - i));
      return {
        dateStr: d.toLocaleDateString('en-US', { month: 'short', day: '2-digit' }),
        date: d.toDateString(),
        count: 0
      };
    });

    transactions.forEach(tx => {
      const txDate = new Date(tx.date).toDateString();
      const day = last30Days.find(d => d.date === txDate);
      if (day) {
        day.count += Math.abs(tx.qty);
      }
    });

    return last30Days.map(d => ({ name: d.dateStr, count: d.count }));
  };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(header => JSON.stringify(row[header] || '')).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderDashboard = () => (
    <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Dashboard</h2>
        <p className="text-slate-500 text-sm">Store stock overview and recent activities.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
        {[
          { label: 'Total Items', value: inventory.length.toString(), icon: Package, color: 'blue' },
          { 
            label: 'Low Stock Alerts', 
            value: inventory.filter(i => i.current < 5).length.toString(), 
            icon: AlertCircle, 
            color: 'red', 
            sub: `${inventory.filter(i => i.current < 5).length} items below reorder level` 
          },
          { 
            label: 'Received Today', 
            value: transactions.filter(t => t.type === 'RECEIVE' && new Date(t.date).toDateString() === new Date().toDateString()).length.toString(), 
            icon: ArrowDownCircle, 
            color: 'emerald' 
          },
          { 
            label: 'Issued Today', 
            value: transactions.filter(t => t.type === 'ISSUE' && new Date(t.date).toDateString() === new Date().toDateString()).length.toString(), 
            icon: ArrowUpCircle, 
            color: 'amber' 
          },
        ].map((stat, i) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={stat.label}
            className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm"
          >
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-slate-500 text-sm font-medium">{stat.label}</h3>
              <stat.icon size={20} className="text-slate-300" />
            </div>
            <div className="text-3xl font-bold text-slate-800 tracking-tight">{stat.value}</div>
            {stat.sub && (
              <p className="text-[10px] text-slate-400 mt-2 font-medium">{stat.sub}</p>
            )}
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8 mb-8">
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-100 shadow-sm p-4 lg:p-6">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp size={18} className="text-orange-500" />
            <h3 className="font-bold text-slate-800">Stock Movement (30 Days)</h3>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={getChartData()}>
                <defs>
                  <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  stroke="#94a3b8" 
                  fontSize={11} 
                  axisLine={false} 
                  tickLine={false}
                />
                <YAxis 
                  stroke="#94a3b8" 
                  fontSize={11} 
                  axisLine={false} 
                  tickLine={false} 
                  tickFormatter={(value) => value === 0 ? '0' : value >= 1000 ? `${value / 1000}k` : value}
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#colorCount)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 lg:p-6 flex flex-col">
           <h3 className="font-bold text-slate-800 mb-6">Recent Activity</h3>
           <div className="flex-1 space-y-6">
             {auditLogs.slice(0, 5).map((activity) => (
               <div key={activity.id} className="flex gap-4">
                 <div className="mt-1">
                   <div className={cn(
                     "w-2 h-2 rounded-full",
                     activity.action === 'ISSUE' ? 'bg-orange-400' : 
                     activity.action === 'RECEIVE' ? 'bg-emerald-400' :
                     'bg-blue-400'
                   )} />
                 </div>
                 <div className="flex-1 overflow-hidden">
                   <p className="text-sm font-bold text-slate-800 leading-tight truncate">
                     {activity.summary}
                   </p>
                   <div className="flex justify-between items-center mt-1">
                     <span className="text-[11px] text-slate-400 truncate max-w-[100px]">{activity.user}</span>
                     <div className="flex items-center gap-1">
                       <span className="text-[10px] font-extrabold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">
                         {activity.action}
                       </span>
                     </div>
                   </div>
                   <p className="text-[10px] text-slate-400 mt-0.5">{new Date(activity.when).toLocaleString()}</p>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden mb-8">
        <div className="p-6 border-b border-slate-50">
          <h3 className="font-bold text-slate-800">Top Moving Items</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[500px]">
            <thead>
              <tr className="bg-slate-50 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="px-6 py-4">SKU</th>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4 text-right">Current Stock</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {inventory.slice(0, 5).sort((a,b) => b.current - a.current).map((item) => (
                <tr key={item.code} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-mono text-xs text-slate-600">{item.code}</td>
                  <td className="px-6 py-4 font-bold text-slate-800 whitespace-nowrap">{item.name}</td>
                  <td className="px-6 py-4 text-right font-bold text-slate-700">{item.current.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderInventoryStock = () => {
    const filteredInventory = inventory.filter(item => {
      const query = searchQueries.inventory.toLowerCase();
      const matchesSearch = item.code.toLowerCase().includes(query) || 
                           item.name.toLowerCase().includes(query) || 
                           item.location.toLowerCase().includes(query) || 
                           item.uses.toLowerCase().includes(query);
      
      const matchesLowStock = lowStockOnly ? item.current < 5 : true;
      
      return matchesSearch && matchesLowStock;
    });

    return (
      <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
        <div className="flex flex-col lg:flex-row justify-between items-start gap-4 mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Inventory Stock</h2>
            <p className="text-slate-500 text-sm">Manage inventory items and view stock levels.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-slate-50 transition-colors shadow-sm">
              <Printer size={16} /> Print / Invoice
            </button>
            <button className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-slate-50 transition-colors shadow-sm">
              <Download size={16} /> Export Excel
            </button>
            <button 
              onClick={handleClearAllStock}
              className="flex items-center gap-2 bg-white border border-red-200 text-red-600 px-3 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-red-50 transition-colors shadow-sm"
            >
              <AlertCircle size={16} /> Clear All Stock
            </button>
            <button className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-slate-50 transition-colors shadow-sm">
              <Upload size={16} /> Import Inventory
            </button>
            <button 
              onClick={() => setShowAddMaterial(true)}
              className="flex items-center gap-2 bg-orange-600 text-white px-4 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-orange-700 transition-colors shadow-sm"
            >
              <Plus size={16} /> Add Material
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-3 mb-6 flex flex-col lg:flex-row gap-4 items-center">
          <div className="w-full lg:flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by code, name, location, uses..."
              value={searchQueries.inventory}
              onChange={(e) => setSearchQueries(prev => ({ ...prev, inventory: e.target.value }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
            />
          </div>
          <div className="w-full lg:w-48 relative">
            <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-600 font-medium">
              <option>All Categories</option>
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
          </div>
          <label className="w-full lg:w-auto flex items-center gap-2 cursor-pointer bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 hover:bg-slate-100 transition-colors shrink-0">
            <input 
              type="checkbox" 
              checked={lowStockOnly}
              onChange={(e) => setLowStockOnly(e.target.checked)}
              className="w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500" 
            />
            <span className="text-sm font-medium text-slate-600">Low stock only</span>
          </label>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[800px]">
              <thead>
                <tr className="bg-slate-50 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="px-6 py-4">ITEM CODE</th>
                  <th className="px-6 py-4">NAME</th>
                  <th className="px-6 py-4">LOCATION</th>
                  <th className="px-6 py-4 text-center">UNIT</th>
                  <th className="px-6 py-4 text-center">USES</th>
                  <th className="px-6 py-4 text-center">OPENING</th>
                  <th className="px-6 py-4 text-center">CURRENT</th>
                  <th className="px-6 py-4 text-center">PRICE</th>
                  <th className="px-6 py-4 text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="text-xs">
                {filteredInventory.length > 0 ? filteredInventory.map((item) => (
                  <tr key={item.code} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 font-mono text-slate-500 flex items-center gap-3">
                      <div className={cn(
                        "w-2 h-2 rounded-full flex-shrink-0",
                        item.status === 'in' ? 'bg-emerald-500' : 'bg-red-500'
                      )} />
                      {item.code}
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-800">{item.name}</td>
                    <td className="px-6 py-4 font-medium text-slate-600">{item.location}</td>
                    <td className="px-6 py-4 text-center text-slate-600">{item.unit}</td>
                    <td className="px-6 py-4 text-center text-slate-400">{item.uses}</td>
                    <td className="px-6 py-4 text-center font-medium text-slate-700">{item.opening}</td>
                    <td className="px-6 py-4 text-center font-bold text-slate-800">
                      <span className={cn(item.current === 0 && "text-red-500")}>
                        {item.current}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center font-medium text-slate-700 font-mono">{item.price.toFixed(2)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center justify-center gap-3">
                        <button className="text-slate-400 hover:text-blue-600 transition-colors">
                          <Edit size={16} />
                        </button>
                        <button 
                          onClick={() => handleDeleteItem(item.code)}
                          className="text-slate-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={9} className="px-6 py-12 text-center text-slate-400 italic font-medium">No inventory items matching your search.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderReceiveStock = () => (
    <div className="flex-1 overflow-y-auto p-8 bg-brand-bg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Receive Material</h2>
        <p className="text-slate-500 text-sm">Record incoming stock from a vendor or supplier.</p>
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b border-slate-50 flex items-center gap-3">
            <div className="bg-emerald-50 p-2 rounded-lg text-emerald-600">
              <ArrowDownCircle size={20} />
            </div>
            <h3 className="font-bold text-slate-800">Goods Receipt</h3>
          </div>
          
          <div className="p-8 space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Search Material</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Search by item code, name, location, or uses..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Material *</label>
              <div className="relative">
                  <select 
                    value={receiveForm.code}
                    onChange={(e) => setReceiveForm(prev => ({ ...prev, code: e.target.value }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all text-slate-600 font-medium"
                  >
                    <option value="">Select material...</option>
                    {inventory.map(item => (
                      <option key={item.code} value={item.code}>{item.name} ({item.code})</option>
                    ))}
                  </select>
                <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Quantity *</label>
                  <input 
                    type="number" 
                    value={receiveForm.qty}
                    onChange={(e) => setReceiveForm(prev => ({ ...prev, qty: parseInt(e.target.value) }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Unit Price</label>
                  <input 
                    type="number" 
                    value={receiveForm.price}
                    onChange={(e) => setReceiveForm(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Vendor / Supplier</label>
                  <input 
                    type="text" 
                    value={receiveForm.party}
                    onChange={(e) => setReceiveForm(prev => ({ ...prev, party: e.target.value }))}
                    placeholder="e.g. FastFix Vendor"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Reference / PO</label>
                  <input 
                    type="text" 
                    value={receiveForm.reference}
                    onChange={(e) => setReceiveForm(prev => ({ ...prev, reference: e.target.value }))}
                    placeholder="e.g. PO-1042"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium"
                  />
                </div>
              </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Notes</label>
              <textarea 
                rows={4}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all font-medium resize-none text-slate-600"
                placeholder="Add any additional information here..."
              />
            </div>

            <div className="flex justify-end pt-4">
              <button 
                onClick={handleReceiveStock}
                disabled={loading}
                className="flex items-center gap-2 bg-emerald-600 text-white px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-emerald-700 transition-all shadow-md active:scale-[0.98] disabled:opacity-50"
              >
                {loading ? 'Recording...' : (
                  <>
                    <ArrowDownCircle size={18} />
                    Record Receipt
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderIssueStock = () => (
    <div className="flex-1 overflow-y-auto p-8 bg-brand-bg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Issue Material</h2>
        <p className="text-slate-500 text-sm">Hand out stock to a job, crew, or department.</p>
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b border-slate-50 flex items-center gap-3">
            <div className="bg-orange-50 p-2 rounded-lg text-orange-600">
              <ArrowUpCircle size={20} />
            </div>
            <h3 className="font-bold text-slate-800">Material Issue</h3>
          </div>
          
          <div className="p-8 space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Search Material</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Search by item code, name, location, or uses..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Material *</label>
              <div className="relative">
                  <select 
                    value={issueForm.code}
                    onChange={(e) => setIssueForm(prev => ({ ...prev, code: e.target.value }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all text-slate-600 font-medium"
                  >
                    <option value="">Select material...</option>
                    {inventory.map(item => (
                      <option key={item.code} value={item.code}>{item.name} ({item.code})</option>
                    ))}
                  </select>
                <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Quantity *</label>
                <input 
                  type="number" 
                  value={issueForm.qty}
                  onChange={(e) => setIssueForm(prev => ({ ...prev, qty: parseInt(e.target.value) }))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Reference</label>
                <input 
                  type="text" 
                  value={issueForm.reference}
                  onChange={(e) => setIssueForm(prev => ({ ...prev, reference: e.target.value }))}
                  placeholder="e.g. ISS-501"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Issued To (Job / Crew / Person)</label>
              <input 
                type="text" 
                value={issueForm.party}
                onChange={(e) => setIssueForm(prev => ({ ...prev, party: e.target.value }))}
                placeholder="e.g. Job 22 - Bracket assembly"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Notes</label>
              <textarea 
                rows={4}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium resize-none text-slate-600"
                placeholder="Add any additional information here..."
              />
            </div>

            <div className="flex justify-end pt-4">
              <button 
                onClick={handleIssueStock}
                disabled={loading}
                className="flex items-center gap-2 bg-orange-600 text-white px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-orange-700 transition-all shadow-md active:scale-[0.98] disabled:opacity-50"
              >
                {loading ? 'Recording...' : (
                  <>
                    <ArrowUpCircle size={18} />
                    Record Issue
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTransactionHistory = () => {
    const filteredTransactions = transactions.filter(tx => {
      const query = searchQueries.transactions.toLowerCase();
      return tx.item.toLowerCase().includes(query) || 
             tx.code.toLowerCase().includes(query) || 
             tx.reference?.toLowerCase().includes(query) || 
             tx.party?.toLowerCase().includes(query) ||
             tx.user?.toLowerCase().includes(query);
    });

    return (
      <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
        <div className="flex flex-col lg:flex-row justify-between items-start gap-4 mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Transaction History</h2>
            <p className="text-slate-500 text-sm">Full ledger of stock movements.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-slate-50 transition-colors shadow-sm">
              <Printer size={16} /> Print / Invoice
            </button>
            <button className="flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-3 py-2 rounded-lg text-xs lg:text-sm font-medium hover:bg-slate-50 transition-colors shadow-sm">
              <Download size={16} /> Export Excel
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-3 mb-6 flex flex-col lg:flex-row gap-4 items-center">
          <div className="w-full lg:flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search reference, party, item, user..."
              value={searchQueries.transactions}
              onChange={(e) => setSearchQueries(prev => ({ ...prev, transactions: e.target.value }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-medium text-slate-600"
            />
          </div>
          <div className="w-full lg:w-40 relative">
            <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-600 font-medium">
              <option>All items</option>
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
          </div>
          <div className="w-full lg:w-32 relative">
            <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-600 font-medium">
              <option>All types</option>
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
          </div>
          <div className="w-full lg:w-32 relative">
            <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-600 font-medium">
              <option>All time</option>
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[1000px]">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="px-6 py-4">DATE</th>
                  <th className="px-6 py-4">TYPE</th>
                  <th className="px-6 py-4">ITEM CODE</th>
                  <th className="px-6 py-4">ITEM</th>
                  <th className="px-6 py-4 text-center">QTY</th>
                  <th className="px-6 py-4 text-center">BALANCE</th>
                  <th className="px-6 py-4">REFERENCE</th>
                  <th className="px-6 py-4">PARTY</th>
                  <th className="px-6 py-4">USER</th>
                </tr>
              </thead>
              <tbody className="text-[11px]">
                {filteredTransactions.length > 0 ? filteredTransactions.map((tx, idx) => (
                  <tr key={idx} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 text-slate-500 whitespace-nowrap">{new Date(tx.date).toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[9px] font-bold",
                        tx.type === 'ISSUE' ? "bg-orange-100 text-orange-600" : "bg-emerald-100 text-emerald-600"
                      )}>
                        {tx.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-slate-500">{tx.code}</td>
                    <td className="px-6 py-4 font-bold text-slate-700">{tx.item}</td>
                    <td className={cn(
                      "px-6 py-4 text-center font-bold",
                      tx.qty < 0 ? "text-red-500" : "text-emerald-500"
                    )}>
                      {tx.qty}
                    </td>
                    <td className="px-6 py-4 text-center font-bold text-slate-800">{tx.balance}</td>
                    <td className="px-6 py-4 font-medium text-slate-500">{tx.reference}</td>
                    <td className="px-6 py-4 font-medium text-slate-500">{tx.party}</td>
                    <td className="px-6 py-4 text-slate-500">{tx.user}</td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={9} className="px-6 py-12 text-center text-slate-400 italic font-medium">No transactions matching your search.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const handleReconcile = async () => {
    const item = inventory.find(i => i.code === physCheckForm.code);
    if (!item) {
      alert('Select a valid material');
      return;
    }
    setLoading(true);
    
    const diff = physCheckForm.actual - item.current;
    
    const { error } = await supabase.from('inventory').update({ current: physCheckForm.actual }).eq('code', physCheckForm.code);
    
    if (!error) {
      await supabase.from('audit_log').insert({
        user: profile?.fullname || 'System',
        action: 'RECONCILE',
        entity: 'INVENTORY',
        summary: `Manually reconciled stock for ${item.name}. Changed from ${item.current} to ${physCheckForm.actual} (Diff: ${diff})`
      });
      await fetchAllData();
      alert('Reconciliation complete');
      setPhysCheckForm({ code: '', actual: 0 });
    } else {
      alert('Error: ' + error.message);
    }
    setLoading(false);
  };

  const renderStockChecks = () => (
    <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Physical Stock Check</h2>
        <p className="text-slate-500 text-sm">Reconcile current system stock with actual physical count.</p>
      </div>

      <div className="max-w-xl bg-white rounded-xl border border-slate-100 shadow-sm p-6 lg:p-8">
        <div className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-700">Select Material *</label>
            <select 
              value={physCheckForm.code}
              onChange={(e) => {
                const code = e.target.value;
                const item = inventory.find(i => i.code === code);
                setPhysCheckForm({ code, actual: item?.current || 0 });
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-medium"
            >
              <option value="">-- Choose Material --</option>
              {inventory.map(item => (
                <option key={item.code} value={item.code}>{item.name} ({item.code})</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
              <span className="text-[10px] uppercase font-bold text-slate-400">System Count</span>
              <div className="text-2xl font-bold text-slate-700">
                {inventory.find(i => i.code === physCheckForm.code)?.current || 0}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Actual Count *</label>
              <input 
                 type="number"
                 value={physCheckForm.actual}
                 onChange={(e) => setPhysCheckForm(prev => ({ ...prev, actual: parseInt(e.target.value) }))}
                 className="w-full bg-white border border-slate-200 rounded-lg px-4 py-2 text-xl font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
              />
            </div>
          </div>

          <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg flex gap-3 italic">
            <AlertCircle size={18} className="text-blue-500 shrink-0" />
            <p className="text-xs text-blue-700">
              Discrepancies will be logged in the audit trail. This will directly update the current stock level.
            </p>
          </div>

          <button 
            disabled={!physCheckForm.code || loading}
            onClick={handleReconcile}
            className="w-full bg-orange-600 text-white font-bold py-3 rounded-lg hover:bg-orange-700 transition-all shadow-md active:scale-[0.98] disabled:opacity-50"
          >
            {loading ? 'Reconciling...' : 'Confirm Reconciliation'}
          </button>
        </div>
      </div>
    </div>
  );

  const renderAuditTrail = () => {
    const filteredLogs = auditLogs.filter(log => {
      const query = searchQueries.audit.toLowerCase();
      return log.user.toLowerCase().includes(query) || 
             log.summary.toLowerCase().includes(query) || 
             log.action.toLowerCase().includes(query) || 
             log.entity.toLowerCase().includes(query);
    });

    return (
      <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-800">Audit Log</h2>
          <p className="text-slate-500 text-sm">Every change in the system, attributed to a user.</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm p-3 mb-6 flex flex-col lg:flex-row gap-4 items-center">
          <div className="w-full lg:flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Search by user, summary, action..."
              value={searchQueries.audit}
              onChange={(e) => setSearchQueries(prev => ({ ...prev, audit: e.target.value }))}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all font-medium text-slate-600"
            />
          </div>
          <div className="w-full lg:w-48 relative">
            <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-600 font-medium">
              <option>All entities</option>
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
          </div>
          <div className="w-full lg:w-48 relative">
            <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all text-slate-600 font-medium">
              <option>All users</option>
            </select>
            <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[900px]">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="px-6 py-4 w-10"></th>
                  <th className="px-6 py-4">WHEN</th>
                  <th className="px-6 py-4">USER</th>
                  <th className="px-6 py-4 text-center">ACTION</th>
                  <th className="px-6 py-4">ENTITY</th>
                  <th className="px-6 py-4">SUMMARY</th>
                </tr>
              </thead>
              <tbody className="text-[11px]">
                {filteredLogs.length > 0 ? filteredLogs.map((log) => (
                  <tr key={log.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4 text-slate-400 group-hover:text-slate-600 font-bold">
                      <ChevronRight size={14} />
                    </td>
                    <td className="px-6 py-4 text-slate-500 whitespace-nowrap">{new Date(log.when).toLocaleString()}</td>
                    <td className="px-6 py-4 font-bold text-slate-700">{log.user}</td>
                    <td className="px-6 py-4 text-center">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[9px] font-extrabold uppercase",
                        log.action === 'ISSUE' ? "bg-orange-100 text-orange-600" : 
                        log.action === 'RECEIVE' ? "bg-emerald-100 text-emerald-600" :
                        "bg-blue-100 text-blue-600"
                      )}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono text-slate-500">{log.entity}</td>
                    <td className="px-6 py-4 text-slate-600 font-bold">{log.summary}</td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic font-medium">No audit logs matching your search.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  const renderUserManagement = () => (
    <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
      <div className="flex flex-col lg:flex-row justify-between items-start gap-4 mb-8">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">User Management</h2>
          <p className="text-slate-500 text-sm">Edit, disable, or delete users.</p>
        </div>
        <button 
          onClick={() => setActiveTab('Sign Up User')}
          className="flex items-center gap-2 bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-orange-700 transition-all shadow-md active:scale-[0.98]"
        >
          <UserPlus size={16} /> Sign Up User
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[800px]">
          <thead>
            <tr className="bg-slate-50 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              <th className="px-6 py-4">USER NAME</th>
              <th className="px-6 py-4">FULL NAME</th>
              <th className="px-6 py-4">EMAIL</th>
              <th className="px-6 py-4 text-center">ROLE</th>
              <th className="px-6 py-4 text-center">STATUS</th>
              <th className="px-6 py-4 text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody className="text-[11px]">
            {users.length > 0 ? users.map((u) => (
              <tr key={u.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 text-slate-500 font-medium">{u.username}</td>
                <td className="px-6 py-4 font-bold text-slate-700">{u.fullname}</td>
                <td className="px-6 py-4 text-slate-500 font-medium">{u.email}</td>
                <td className="px-6 py-4 text-center">
                  <span className={cn(
                    "px-2 py-0.5 rounded text-[8px] font-extrabold uppercase",
                    u.role === 'ADMIN' ? "bg-purple-100 text-purple-600" : "bg-slate-100 text-slate-500"
                  )}>
                    {u.role}
                  </span>
                </td>
                <td className="px-6 py-4 text-center">
                  <span className={cn(
                    "px-2 py-0.5 rounded text-[8px] font-extrabold uppercase",
                    u.status === 'Active' ? "bg-emerald-100 text-emerald-600" : "bg-red-50 text-red-400"
                  )}>
                    {u.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-end gap-4">
                    <button className="flex items-center gap-1.5 text-slate-600 hover:text-blue-600 transition-colors font-bold text-[10px]">
                      <Edit size={14} /> Edit
                    </button>
                    {u.status === 'Active' ? (
                      <button className="flex items-center gap-1.5 text-slate-600 hover:text-orange-500 transition-colors font-bold text-[10px]">
                        <Ban size={14} /> Disable
                      </button>
                    ) : (
                      <button className="flex items-center gap-1.5 text-slate-600 hover:text-emerald-500 transition-colors font-bold text-[10px]">
                        <CheckCircle size={14} /> Enable
                      </button>
                    )}
                    <button className="flex items-center gap-1.5 text-red-500 hover:text-red-700 transition-colors font-bold text-[10px]">
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-slate-400 italic">No users found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  </div>
);

  const renderSignUpUser = () => (
    <div className="flex-1 overflow-y-auto p-8 bg-brand-bg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">Sign Up New User</h2>
        <p className="text-slate-500 text-sm">Admin only. Create a login for a team member.</p>
      </div>

      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-8 py-6 border-b border-slate-50 flex items-center gap-3">
            <div className="bg-orange-50 p-2 rounded-lg text-orange-600">
              <UserPlus size={20} />
            </div>
            <h3 className="font-bold text-slate-800">User Details</h3>
          </div>
          
          <div className="p-8 space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700">Full Name *</label>
              <input 
                type="text" 
                value={signUpForm.fullname}
                onChange={(e) => setSignUpForm(prev => ({ ...prev, fullname: e.target.value }))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">User Name *</label>
                <input 
                  type="text" 
                  value={signUpForm.username}
                  onChange={(e) => setSignUpForm(prev => ({ ...prev, username: e.target.value }))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Password *</label>
                <input 
                  type="password" 
                  value={signUpForm.password}
                  onChange={(e) => setSignUpForm(prev => ({ ...prev, password: e.target.value }))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Email *</label>
                <input 
                  type="email" 
                  value={signUpForm.email}
                  onChange={(e) => setSignUpForm(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all font-medium"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Role *</label>
                <div className="relative">
                  <select 
                    value={signUpForm.role}
                    onChange={(e) => setSignUpForm(prev => ({ ...prev, role: e.target.value }))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-orange-500/20 transition-all text-slate-600 font-medium"
                  >
                    <option value="USER">User</option>
                    <option value="ADMIN">Admin</option>
                  </select>
                  <Filter className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={16} />
                </div>
              </div>
            </div>

            <div className="bg-slate-50 rounded-xl p-6 border border-slate-100">
              <p className="text-[11px] text-slate-600 leading-relaxed">
                <strong className="text-slate-800">Admin</strong> has full access to all features.<br />
                <strong className="text-slate-800">User</strong> can view and manage transactions but cannot add/delete materials, view audit trail, or manage users.
              </p>
            </div>

            <div className="flex justify-end pt-4">
              <button 
                onClick={handleSignUpUser}
                disabled={loading}
                className="flex items-center gap-2 bg-orange-600 text-white px-6 py-2.5 rounded-lg text-sm font-bold hover:bg-orange-700 transition-all shadow-md active:scale-[0.98] disabled:opacity-50"
              >
                {loading ? 'Creating...' : (
                  <>
                    <UserPlus size={18} />
                    Create User
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSystemBackup = () => (
    <div className="flex-1 overflow-y-auto p-4 lg:p-8 bg-brand-bg">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-800">System Backup</h2>
        <p className="text-slate-500 text-sm">Export all system entities to CSV files for local storage.</p>
      </div>

      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-6 lg:px-8 py-6 border-b border-slate-50 flex items-center gap-3">
            <div className="bg-orange-50 p-2 rounded-lg text-orange-600">
              <DatabaseIcon size={20} />
            </div>
            <h3 className="font-bold text-slate-800">Export System Data</h3>
          </div>
          
          <div className="p-6 lg:p-8">
            <ul className="space-y-4 mb-8">
              {[
                { name: 'Inventory', desc: '(all materials with stock levels)', data: inventory, file: 'inventory' },
                { name: 'Transaction History', desc: '(every receive, issue, adjust)', data: transactions, file: 'transactions' },
                { name: 'Audit Trail', desc: '(full activity log)', data: auditLogs, file: 'audit_log' },
                { name: 'Users', desc: '(user list)', data: users, file: 'users' }
              ].map((sheet, i) => (
                <li key={i} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="flex items-center gap-3 text-sm text-slate-600">
                    <div className="w-1.5 h-1.5 rounded-full bg-orange-400" />
                    <div>
                      <span className="font-bold text-slate-700 block sm:inline">File {i + 1} — {sheet.name}</span>
                      <span className="text-[11px] text-slate-400 font-medium sm:ml-2">{sheet.desc}</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => exportToCSV(sheet.data, sheet.file)}
                    className="text-[10px] font-bold text-orange-600 hover:text-orange-700 uppercase"
                  >
                    Download CSV
                  </button>
                </li>
              ))}
            </ul>

            <button 
              onClick={() => {
                exportToCSV(inventory, 'inventory');
                exportToCSV(transactions, 'transactions');
                exportToCSV(auditLogs, 'audit_trail');
                exportToCSV(users, 'users_list');
                alert('All system files have been exported.');
              }}
              className="w-full bg-orange-600 text-white font-bold py-3.5 rounded-xl hover:bg-orange-700 shadow-lg active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Download size={20} />
              Full System Backup (.CSV)
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-brand-bg">
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "bg-brand-sidebar flex-shrink-0 flex flex-col transition-all duration-300 z-50 fixed inset-y-0 left-0 lg:relative lg:translate-x-0 w-64",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 border-b border-white/10 flex flex-col items-center relative">
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="lg:hidden absolute top-4 right-4 text-slate-400 hover:text-white"
          >
            <X size={20} />
          </button>
          <div className="h-10 w-[120px] mb-4 flex items-center justify-center overflow-hidden">
            <img 
              src="/src/assets/images/regenerated_image_1777800317392.png" 
              alt="C2C Pharma Logo" 
              className="h-full w-full object-contain"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // Fallback if logo not found
                e.currentTarget.src = 'https://picsum.photos/seed/c2c/120/40';
              }}
            />
          </div>
          <h1 className="text-white font-bold text-lg text-center leading-tight">
            C2C Pharma Ltd.<br/>
            <span className="text-xs font-normal text-slate-400">STOCK MANAGER</span>
          </h1>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4">
            {sidebarItems.map((item) => (
            <button
              key={item.label}
              onClick={() => {
                setActiveTab(item.label);
                if (window.innerWidth < 1024) setIsSidebarOpen(false);
              }}
              className={cn(
                "w-full flex items-center gap-3 px-6 py-3 text-sm font-medium transition-colors text-left",
                activeTab === item.label 
                  ? "text-white bg-brand-active border-r-4 border-white" 
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              <item.icon size={18} />
              {item.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 px-4 lg:px-8 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-600 hover:bg-slate-50 rounded-lg"
            >
              <Menu size={20} />
            </button>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
              </span>
              <span className="text-xs text-slate-500 font-mono">
                {new Date().toLocaleTimeString('en-GB')}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 lg:gap-4">
            <div className="hidden sm:flex flex-col text-right mr-2">
              <span className="text-sm font-semibold text-slate-700">{profile?.fullname || user?.email || 'Loading...'}</span>
              <span className="text-[10px] text-slate-400 font-bold uppercase">{profile?.role || 'User'}</span>
            </div>
            <div className="w-9 h-9 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold text-sm">
              {(profile?.fullname || user?.email || '??').substring(0, 2).toUpperCase()}
            </div>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 text-slate-600 hover:text-red-600 transition-colors px-3 py-1.5 border border-slate-200 rounded-lg text-sm font-medium ml-2"
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        </header>

        {/* Dashboard Stats */}
        {activeTab === 'Dashboard' 
          ? renderDashboard() 
          : activeTab === 'Inventory Stock' 
          ? renderInventoryStock() 
          : activeTab === 'Receive Stock'
          ? renderReceiveStock()
          : activeTab === 'Issue Stock'
          ? renderIssueStock()
          : activeTab === 'Transaction History'
          ? renderTransactionHistory()
          : activeTab === 'Stock Checks'
          ? renderStockChecks()
          : activeTab === 'Audit Trail'
          ? renderAuditTrail()
          : activeTab === 'User Management'
          ? renderUserManagement()
          : activeTab === 'Sign Up User'
          ? renderSignUpUser()
          : activeTab === 'System Backup'
          ? renderSystemBackup()
          : (
          <div className="flex-1 flex items-center justify-center text-slate-400 bg-brand-bg">
            <div className="text-center">
              <LayoutDashboard size={48} className="mx-auto mb-4 opacity-10" />
              <p className="text-lg font-medium">Content for {activeTab} is under development.</p>
            </div>
          </div>
        )}

        {/* Add Material Modal */}
        {showAddMaterial && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden"
            >
              <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-orange-50 p-2 rounded-lg text-orange-600">
                    <Package size={20} />
                  </div>
                  <h3 className="font-bold text-slate-800">Add New Material</h3>
                </div>
                <button onClick={() => setShowAddMaterial(false)} className="text-slate-400 hover:text-slate-600 transition-colors">
                  <LogIn size={20} className="rotate-45" /> {/* Close icon substitute */}
                </button>
              </div>
              
              <div className="p-8 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Item Code *</label>
                    <input 
                      type="text" 
                      required
                      value={addMaterialForm.code}
                      onChange={(e) => setAddMaterialForm(prev => ({ ...prev, code: e.target.value }))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                      placeholder="e.g. CE-02-08-0001"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Name *</label>
                    <input 
                      type="text" 
                      required
                      value={addMaterialForm.name}
                      onChange={(e) => setAddMaterialForm(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                      placeholder="Item name"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Location</label>
                    <input 
                      type="text" 
                      value={addMaterialForm.location}
                      onChange={(e) => setAddMaterialForm(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                      placeholder="e.g. 13D"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Unit</label>
                    <input 
                      type="text" 
                      value={addMaterialForm.unit}
                      onChange={(e) => setAddMaterialForm(prev => ({ ...prev, unit: e.target.value }))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                      placeholder="e.g. Pcs, Nos, Feet"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Opening Stock</label>
                    <input 
                      type="number" 
                      value={addMaterialForm.opening}
                      onChange={(e) => setAddMaterialForm(prev => ({ ...prev, opening: parseInt(e.target.value) }))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                    />
                  </div>
                  <div className="space-y-1.5 col-span-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Price</label>
                    <input 
                      type="number" 
                      value={addMaterialForm.price}
                      onChange={(e) => setAddMaterialForm(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all font-medium"
                      placeholder="0.00"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-6">
                  <button 
                    onClick={() => setShowAddMaterial(false)}
                    className="px-6 py-2.5 rounded-xl text-sm font-bold text-slate-500 hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleAddMaterial}
                    disabled={loading}
                    className="px-8 py-2.5 rounded-xl text-sm font-bold bg-orange-600 text-white hover:bg-orange-700 shadow-lg active:scale-[0.98] disabled:opacity-50 transition-all"
                  >
                    {loading ? 'Adding...' : 'Add Material'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* Footer */}
        <footer className="h-5 bg-slate-50 border-t border-slate-200 flex items-center justify-center flex-shrink-0">
          <p className="text-[9px] text-slate-400 font-medium tracking-wide">
            Designed by <span className="text-slate-500">Md. Bellal Hosen</span>. Engineering Department, C2C Pharma Ltd.
          </p>
        </footer>
      </main>
    </div>
  );
}

