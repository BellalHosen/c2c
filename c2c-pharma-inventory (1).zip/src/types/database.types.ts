export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      inventory: {
        Row: {
          code: string
          name: string
          location: string | null
          unit: string | null
          uses: string | null
          opening: number
          current: number
          price: number
          status: 'in' | 'out'
          created_at: string
          updated_at: string
        }
        Insert: {
          code: string
          name: string
          location?: string | null
          unit?: string | null
          uses?: string | null
          opening?: number
          current?: number
          price?: number
          status?: 'in' | 'out'
          created_at?: string
          updated_at?: string
        }
        Update: {
          code?: string
          name?: string
          location?: string | null
          unit?: string | null
          uses?: string | null
          opening?: number
          current?: number
          price?: number
          status?: 'in' | 'out'
          created_at?: string
          updated_at?: string
        }
      }
      transactions: {
        Row: {
          id: string
          date: string
          type: 'ISSUE' | 'RECEIVE'
          code: string
          item: string
          qty: number
          balance: number
          reference: string | null
          party: string | null
          user: string
          created_at: string
        }
        Insert: {
          id?: string
          date?: string
          type: 'ISSUE' | 'RECEIVE'
          code: string
          item: string
          qty: number
          balance: number
          reference?: string | null
          party?: string | null
          user: string
          created_at?: string
        }
        Update: {
          id?: string
          date?: string
          type?: 'ISSUE' | 'RECEIVE'
          code?: string
          item?: string
          qty?: number
          balance?: number
          reference?: string | null
          party?: string | null
          user?: string
          created_at?: string
        }
      }
      audit_log: {
        Row: {
          id: string
          when: string
          user: string
          action: string
          entity: string
          summary: string
          created_at: string
        }
        Insert: {
          id?: string
          when?: string
          user: string
          action: string
          entity: string
          summary: string
          created_at?: string
        }
        Update: {
          id?: string
          when?: string
          user?: string
          action?: string
          entity?: string
          summary?: string
          created_at?: string
        }
      }
      profiles: {
        Row: {
          id: string
          username: string
          fullname: string
          email: string
          role: 'ADMIN' | 'USER'
          status: 'Active' | 'Disabled'
          updated_at: string
        }
        Insert: {
          id: string
          username: string
          fullname: string
          email: string
          role?: 'ADMIN' | 'USER'
          status?: 'Active' | 'Disabled'
          updated_at?: string
        }
        Update: {
          id?: string
          username?: string
          fullname?: string
          email?: string
          role?: 'ADMIN' | 'USER'
          status?: 'Active' | 'Disabled'
          updated_at?: string
        }
      }
    }
  }
}
