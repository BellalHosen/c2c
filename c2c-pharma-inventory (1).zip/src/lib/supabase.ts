import { createClient } from '@supabase/supabase-js';

const supabaseUrl = (import.meta as any).env.VITE_SUPABASE_URL || 'https://ujmyxrzezqbndvyexoxj.supabase.co';
const supabaseAnonKey = (import.meta as any).env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVqbXl4cnplenFibmR2eWV4b3hqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzgwNjE0NjgsImV4cCI6MjA5MzYzNzQ2OH0.lr4JW7JTe9l1HupKbEBN5tYJgCLzY_-0NjeMoxGrhUk';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
